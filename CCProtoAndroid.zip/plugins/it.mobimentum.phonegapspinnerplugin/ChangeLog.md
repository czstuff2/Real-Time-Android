1.0.3
-----

* Android: added "timeout" param support

